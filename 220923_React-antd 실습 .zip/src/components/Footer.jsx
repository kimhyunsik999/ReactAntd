import React from "react";

const Footer = () => (
  <div className="footer_area">HEADER AREA</div>
)

export default Footer;