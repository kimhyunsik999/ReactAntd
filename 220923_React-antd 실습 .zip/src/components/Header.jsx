import React from "react";

const Header = () => (
  <div className="header_area">HEADER AREA</div>
)

export default Header;