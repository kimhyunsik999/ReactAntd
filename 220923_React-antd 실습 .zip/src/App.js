import "./styles.css";
import "antd/dist/antd.css";

import Header from "./components/Header";
import Footer from "./components/Footer";
import FormSample from "./components/FormSample";
import GridSample from "./components/GridSample";
import TreeSample from "./components/TreeSample";

export default function App() {
  return (
    <div className="App">
      <Header />
      <div className="FormArea">
        <h1>form 영역</h1>
        <FormSample />
      </div>
      <div className="layoutTreeGrid">
        <div className="TreeArea">
          <h1>Tree 영역</h1>
          <TreeSample />
        </div>
        <div className="GridArea">
          <h1>grid 영역</h1>
          <GridSample />
        </div>
      </div>
      <Footer />
    </div>
  );
}
